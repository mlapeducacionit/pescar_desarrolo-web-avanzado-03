# Clase 02 - Maquetador Web Avanzado

## Incializar un proyecto de Vite de manera rápida

```sh
npm create vite@latest ./ -- --template vanilla
```

## Detengo el servidor de desarrollo

Ctrl + C | q + enter